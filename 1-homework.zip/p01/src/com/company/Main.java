package com.company;

public class Main {

    public static void main(String[] args) {
        String myHomeWork;

        final int NUM = 10;
        int word = 5;
        String myHomeWork = 15;
        System.out.println( final int,String)}

        if(NUM < 0) {

            System.out.println("Вы сохранили отрицательное число");}
        if(NUM >0) {

            System.out.println("Вы сохранили положительное число");}
        else{
            System.out.println("Вы сохранили нуль")}




    }

}