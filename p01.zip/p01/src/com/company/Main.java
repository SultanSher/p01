package com.company;

public class Main {

    public static void main(String[] args) {
        String homeWork = "fifteen";

        final int CONST_NUM = 10;
        String word = "five";

        System.out.print("fifteen");
        System.out.print(10);
        System.out.print("five");


        if (CONST_NUM < 0) {
            System.out.println("Вы сохранили отрицательное число");
        }

        if (CONST_NUM > 0) {
            System.out.println("Вы сохранили положительное число");
        }

    }
}


